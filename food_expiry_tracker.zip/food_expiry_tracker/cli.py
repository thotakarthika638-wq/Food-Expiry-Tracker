"""FreshKeep - terminal interface (menu-driven, ANSI-styled).  Run: python cli.py"""
from __future__ import annotations

import os
import sys
from datetime import date
from pathlib import Path

from core import CATEGORIES, LOCATIONS, UNITS, Tracker, ValidationError
from core import reports, sample_data
from core.models import CRITICAL, EXPIRED, FRESH, SOON, STATUS_ORDER
from core.validation import clean_choice, clean_name, clean_quantity, parse_date

os.system("")  # enables ANSI colours on Windows terminals
C = {"r": "\033[91m", "g": "\033[92m", "y": "\033[93m", "o": "\033[38;5;208m",
     "b": "\033[94m", "c": "\033[96m", "d": "\033[2m", "B": "\033[1m", "x": "\033[0m"}
STATUS_COLOR = {EXPIRED: "r", CRITICAL: "o", SOON: "y", FRESH: "g"}
DATA_FILE = Path(__file__).parent / "data" / "pantry.json"
PAGE = 15


def paint(text, *codes):
    return "".join(C[c] for c in codes) + str(text) + C["x"]


def banner():
    print(paint("""
  ______              _     _  __
 |  ____|            | |   | |/ /
 | |__ _ __ ___  ___ | |__ | ' / ___  ___ _ __
 |  __| '__/ _ \\/ __|| '_ \\|  < / _ \\/ _ \\ '_ \\
 | |  | | |  __/\\__ \\| | | | . \\  __/  __/ |_) |
 |_|  |_|  \\___||___/|_| |_|_|\\_\\___|\\___| .__/
                                          | |
""", "g", "B") + paint("  Food Expiry Tracker  |  StudentLife Hack #62\n", "d"))


# ---------- centralised input wrappers: loop until valid ----------
def ask(prompt, parser, default=None, allow_blank=False):
    while True:
        hint = f" [{default}]" if default not in (None, "") else ""
        raw = input(paint(f"  {prompt}{hint}: ", "c")).strip()
        if raw == "" and default is not None:
            raw = str(default)
        if raw == "" and allow_blank:
            return ""
        try:
            return parser(raw)
        except ValidationError as e:
            print(paint("   x " + "; ".join(e.errors), "r"))


def pick(prompt, options, default=None):
    print(paint("   " + " | ".join(f"{n}. {o}" for n, o in enumerate(options, 1)), "d"))

    def parser(s):
        if s.isdigit() and 1 <= int(s) <= len(options):
            return options[int(s) - 1]
        return clean_choice(s, options, prompt)
    return ask(prompt + " (number or name)", parser, default)


def menu_int(prompt, lo, hi, default=None):
    def parser(s):
        if not s.isdigit() or not lo <= int(s) <= hi:
            raise ValidationError(f"Enter a whole number between {lo} and {hi}.")
        return int(s)
    return ask(prompt, parser, default)


# ---------- presentation ----------
def table(t: Tracker, items, today):
    if not items:
        print(paint("\n  (no matching items)\n", "d"))
        return
    head = f"  {'ID':<9}{'Name':<24}{'Category':<20}{'Qty':<10}{'Expiry':<12}{'Days':>5}  {'Status':<14}"
    for start in range(0, len(items), PAGE):
        print("\n" + paint(head, "B"))
        print("  " + "-" * (len(head) - 2))
        for i in items[start:start + PAGE]:
            st = t.status_of(i, today)
            qty = f"{i.quantity:g} {i.unit}"
            print(f"  {i.id:<9}{i.name[:23]:<24}{i.category[:19]:<20}{qty[:9]:<10}"
                  f"{i.expiry_date!s:<12}{i.days_left(today):>5}  " + paint(f"{st:<14}", STATUS_COLOR[st]))
        shown = min(start + PAGE, len(items))
        print(paint(f"\n  Showing {shown} of {len(items)}", "d"))
        if shown < len(items) and input(paint("  Enter = next page, q = stop: ", "c")).lower() == "q":
            break


def show_alerts(t: Tracker, today, limit=12):
    alerts = t.alerts(today)
    if not alerts:
        print(paint("  All clear - nothing needs attention.", "g"))
        return
    for a in alerts[:limit]:
        col = {"critical": "r", "warning": "y", "info": "b"}[a["level"]]
        print("  " + paint({"critical": "!!", "warning": " !", "info": " i"}[a["level"]], col, "B")
              + " " + a["message"])
    if len(alerts) > limit:
        print(paint(f"  ... and {len(alerts) - limit} more (see Warnings menu)", "d"))


# ---------- actions ----------
def add_item(t, today):
    print(paint("\n  Add a pantry item", "B"))
    name = ask("Name", clean_name)
    category = pick("Category", CATEGORIES)
    qty = ask("Quantity", clean_quantity)
    unit = pick("Unit", UNITS, "pcs")
    location = pick("Location", LOCATIONS, "Pantry")
    purchase = ask("Purchase date YYYY-MM-DD", lambda s: parse_date(s, "Purchase date"), today.isoformat())
    while True:
        expiry = ask("Expiry date YYYY-MM-DD", lambda s: parse_date(s, "Expiry date"))
        if expiry >= purchase:
            break
        print(paint("   x Expiry date cannot be before the purchase date.", "r"))
    notes = ask("Notes (optional)", str, allow_blank=True)
    try:
        item, warns = t.add(dict(name=name, category=category, quantity=qty, unit=unit,
                                 location=location, purchase_date=purchase, expiry_date=expiry,
                                 notes=notes), today)
    except ValidationError as e:
        print(paint("  Could not save: " + "; ".join(e.errors), "r"))
        return
    print(paint(f"\n  + Saved '{item.name}' (id {item.id}).", "g"))
    for w in warns:
        print(paint("   ! " + w, "y"))


def pick_item(t):
    ident = ask("Item id", lambda s: s, allow_blank=True)
    return t.get(ident) if ident else None


def delete_item(t, today):
    table(t, sorted(t.items, key=lambda x: x.expiry_date), today)
    item = pick_item(t)
    if not item:
        print(paint("  No item with that id.", "r"))
        return
    if input(paint(f"  Delete '{item.name}'? (y/N): ", "c")).lower() == "y":
        t.delete(item.id)
        print(paint("  Deleted.", "g"))


def edit_item(t, today):
    table(t, sorted(t.items, key=lambda x: x.expiry_date), today)
    item = pick_item(t)
    if not item:
        print(paint("  No item with that id.", "r"))
        return
    print(paint("  Press Enter to keep the current value.", "d"))
    raw = item.to_dict()
    raw["name"] = ask("Name", clean_name, item.name)
    raw["quantity"] = ask("Quantity", clean_quantity, f"{item.quantity:g}")
    raw["expiry_date"] = ask("Expiry date", lambda s: parse_date(s, "Expiry date"), item.expiry_date.isoformat())
    raw["notes"] = ask("Notes", str, item.notes, allow_blank=True)
    try:
        t.update(item.id, raw, today)
        print(paint("  Updated.", "g"))
    except ValidationError as e:
        print(paint("  " + "; ".join(e.errors), "r"))


def search(t, today):
    kw = ask("Keyword (blank = any)", str, allow_blank=True)
    cat = ask("Category filter (number/name, blank = any)",
              lambda s: (CATEGORIES[int(s) - 1] if s.isdigit() and 1 <= int(s) <= len(CATEGORIES)
                         else clean_choice(s, CATEGORIES, "Category")), allow_blank=True) \
        if input(paint("  Filter by category? (y/N): ", "c")).lower() == "y" else ""
    table(t, t.search(kw, [cat] if cat else None, today=today), today)


def summary(t, today):
    s = t.summary(today)
    print(paint("\n  EXECUTIVE SUMMARY", "B"), paint(f"as of {s['as_of']}", "d"))
    print(f"  Total items ........ {s['total_items']}")
    print(f"  Freshness score .... " + paint(f"{s['freshness_score']}/100", "g" if s['freshness_score'] >= 60 else "r", "B"))
    print(f"  At risk ............ {s['at_risk']} ({s['at_risk_pct']}%)")
    print(f"  Avg days left ...... {s['avg_days_left']}    Avg shelf life: {s['avg_shelf_life']} days")
    print(f"  Soonest to expire .. {s['soonest_item']}")
    print(f"  Riskiest category .. {s['riskiest_category']} ({s['riskiest_category_pct']}% at risk)")
    print(paint("\n  Status distribution", "B"))
    peak = max(s["status_counts"].values() or [1]) or 1
    for k in STATUS_ORDER:
        v = s["status_counts"][k]
        print(f"  {k:<14}{paint('#' * round(30 * v / peak), STATUS_COLOR[k])} {v}")
    print(paint("\n  By category", "B"))
    print(f"  {'Category':<22}{'Items':>6}{'At risk':>9}{'Risk %':>8}{'Avg qty':>9}")
    for c, v in s["category_stats"].items():
        print(f"  {c:<22}{v['items']:>6}{v['at_risk']:>9}{v['risk_pct']:>8}{v['avg_quantity']:>9}")
    print(paint("\n  Warnings", "B"))
    show_alerts(t, today, 6)


def export(t, today):
    for p in reports.export_all(t, Path(__file__).parent / "exports", today):
        print(paint(f"  + wrote {p}", "g"))
    if not any(p.suffix == ".png" for p in Path(__file__).parent.joinpath("exports").glob("*.png")):
        print(paint("  (install matplotlib to also get a PNG chart)", "d"))


def bulk_import(t, today):
    path = ask("Path to CSV file", lambda s: s)
    try:
        text = Path(path).expanduser().read_text(encoding="utf-8-sig")
    except OSError as e:
        print(paint(f"  Cannot read file: {e}", "r"))
        return
    res = t.import_csv(text, today)
    print(paint("\n  " + res.error_log().replace("\n", "\n  "), "g" if not res.errors else "y"))
    log = Path(__file__).parent / "exports" / "import_errors.log"
    if res.errors or res.fatal:
        log.parent.mkdir(exist_ok=True)
        log.write_text(res.error_log(), encoding="utf-8")
        print(paint(f"\n  Row-by-row error log saved to {log}", "d"))


def load_sample(t, today):
    res = t.import_csv(sample_data.to_csv(sample_data.build_rows(today)), today)
    print(paint(f"  Loaded {res.added} sample items ({res.duplicates} duplicates skipped).", "g"))


MENU = [
    ("Dashboard & warnings", lambda t, d: (summary(t, d))),
    ("Add item", add_item),
    ("View all items", lambda t, d: table(t, sorted(t.items, key=lambda x: x.expiry_date), d)),
    ("Items expiring soon", lambda t, d: table(t, t.expiring_within(t.warn_days, d), d)),
    ("Expired items", lambda t, d: table(t, t.expired(d), d)),
    ("Search / filter", search),
    ("Edit item", edit_item),
    ("Delete item", delete_item),
    ("Export reports (MD / TXT / CSV / PNG)", export),
    ("Bulk import CSV", bulk_import),
    ("Load sample data", load_sample),
]


def main():
    today = date.today()
    t = Tracker(DATA_FILE)
    banner()
    for msg in t.load_issues:
        print(paint("  ! " + msg, "y"))
    print(paint(f"  {len(t.items)} item(s) loaded from {t.path.name}\n", "d"))
    show_alerts(t, today, 5)
    while True:
        print(paint("\n  MAIN MENU", "B"))
        for n, (label, _) in enumerate(MENU, 1):
            print(f"   {n:>2}. {label}")
        print("    0. Exit")
        choice = menu_int("Choose", 0, len(MENU))
        if choice == 0:
            print(paint("\n  Saved. Stay fresh!\n", "g"))
            return
        try:
            MENU[choice - 1][1](t, today)
        except (KeyboardInterrupt, EOFError):
            print(paint("\n  (cancelled)", "d"))


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nBye!")
        sys.exit(0)
