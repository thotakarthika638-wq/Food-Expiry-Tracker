import json
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import Tracker, ValidationError, build_item, reports, sample_data  # noqa: E402
from core.validation import clean_quantity, parse_date  # noqa: E402

TODAY = date(2026, 11, 22)


def raw(**kw):
    base = dict(name="Milk", category="Dairy", quantity="2", unit="L", location="Fridge",
                purchase_date="2026-11-20", expiry_date="2026-11-30")
    base.update(kw)
    return base


class ValidationTests(unittest.TestCase):
    def test_valid(self):
        item, warns = build_item(raw(), TODAY)
        self.assertEqual(item.quantity, 2.0)
        self.assertEqual(warns, [])

    def test_collects_all_errors(self):
        with self.assertRaises(ValidationError) as cm:
            build_item(raw(name="", quantity="abc", category="Gadgets", expiry_date="nope"), TODAY)
        self.assertGreaterEqual(len(cm.exception.errors), 4)

    def test_quantity_bounds(self):
        for bad in ("0", "-1", "10001", "nan", "inf", "", None, True):
            with self.assertRaises(ValidationError):
                clean_quantity(bad)
        self.assertEqual(clean_quantity("0.01"), 0.01)
        self.assertEqual(clean_quantity("10000"), 10000)

    def test_dates(self):
        self.assertEqual(parse_date("22/11/2026"), TODAY)
        for bad in ("2026-02-30", "1999-01-01", "", "yesterday"):
            with self.assertRaises(ValidationError):
                parse_date(bad)

    def test_expiry_before_purchase(self):
        with self.assertRaises(ValidationError):
            build_item(raw(expiry_date="2026-11-01"), TODAY)

    def test_anomaly_warnings(self):
        _, w = build_item(raw(expiry_date="2035-01-01"), TODAY)
        self.assertTrue(any("5 years" in x for x in w))
        _, w = build_item(raw(purchase_date="2026-11-01", expiry_date="2026-11-10"), TODAY)
        self.assertTrue(any("expired" in x for x in w))


class TrackerTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = Path(self.dir.name) / "p.json"
        self.t = Tracker(self.path)

    def tearDown(self):
        self.dir.cleanup()

    def test_status_boundaries(self):
        for offset, expected in [(-1, "Expired"), (0, "Critical"), (2, "Critical"),
                                 (3, "Expiring Soon"), (7, "Expiring Soon"), (8, "Fresh")]:
            item, _ = self.t.add(raw(purchase_date="2026-11-01",
                                     expiry_date=(TODAY + timedelta(days=offset)).isoformat()), TODAY)
            self.assertEqual(self.t.status_of(item, TODAY), expected, offset)

    def test_persistence_roundtrip_json_and_csv(self):
        self.t.add(raw(), TODAY)
        self.assertEqual(len(Tracker(self.path).items), 1)
        self.t.switch_file(Path(self.dir.name) / "p.csv")
        self.assertEqual(Tracker(Path(self.dir.name) / "p.csv").items[0].name, "Milk")

    def test_corrupt_and_missing_files(self):
        self.path.write_text("{ not json")
        t = Tracker(self.path)
        self.assertEqual(t.items, [])
        self.assertTrue(t.load_issues)
        self.assertTrue(list(Path(self.dir.name).glob("p.json.corrupt-*")))
        self.assertEqual(json.loads(self.path.read_text())["items"], [])

    def test_invalid_records_skipped_on_load(self):
        self.path.write_text(json.dumps({"items": [raw(), raw(quantity="-5"), "junk"]}))
        t = Tracker(self.path)
        self.assertEqual(len(t.items), 1)
        self.assertEqual(len(t.load_issues), 2)

    def test_search_edit_delete(self):
        a, _ = self.t.add(raw(), TODAY)
        self.t.add(raw(name="Apples", category="Fruits", unit="kg", location="Counter"), TODAY)
        self.assertEqual(len(self.t.search("milk")), 1)
        self.assertEqual(len(self.t.search(categories=["Fruits"])), 1)
        self.t.update(a.id, raw(name="Oat Milk"), TODAY)
        self.assertEqual(self.t.get(a.id).name, "Oat Milk")
        self.assertTrue(self.t.delete(a.id))
        self.assertFalse(self.t.delete("zzz"))

    def test_summary_alerts_and_breach(self):
        self.t.import_csv(sample_data.to_csv(sample_data.build_rows(TODAY)), TODAY)
        s = self.t.summary(TODAY)
        self.assertEqual(s["total_items"], 40)
        self.assertEqual(sum(s["status_counts"].values()), 40)
        levels = {a["level"] for a in self.t.alerts(TODAY)}
        self.assertTrue({"critical", "warning", "info"} <= levels)

    def test_empty_summary_safe(self):
        s = self.t.summary(TODAY)
        self.assertEqual(s["total_items"], 0)
        self.assertIsNone(s["avg_days_left"])

    def test_bulk_import_errors_and_dupes(self):
        res = self.t.import_csv(sample_data.legacy_import_sample(TODAY), TODAY)
        self.assertEqual((res.added, res.duplicates, len(res.errors)), (2, 1, 5))
        self.assertIn("Row 3", res.error_log())
        self.assertTrue(self.t.import_csv("foo,bar\n1,2\n", TODAY).fatal)

    def test_reports(self):
        self.t.import_csv(sample_data.to_csv(sample_data.build_rows(TODAY)), TODAY)
        self.assertIn("Executive Summary", reports.to_markdown(self.t, TODAY))
        self.assertIn("AUDIT LOG", reports.to_text_audit(self.t, TODAY))
        self.assertEqual(reports.to_csv_report(self.t, TODAY).count("\n"), 41)
        files = reports.export_all(self.t, Path(self.dir.name) / "out", TODAY)
        self.assertGreaterEqual(len(files), 3)


if __name__ == "__main__":
    unittest.main()
