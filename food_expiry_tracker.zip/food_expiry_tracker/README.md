# 🥗 FreshKeep - Food Expiry Tracker
StudentLife Hack · Project #62 · Food & Agriculture

Record pantry items, see what is about to expire, and cut food waste. Two front-ends share one
standard-library core (Python 3.10+):

| Front-end | Command | Best for |
|---|---|---|
| **Streamlit web UI** (modern, all features) | `streamlit run app.py` | the demo |
| **ANSI terminal menu** | `python cli.py` | brief's "interactive terminal interface" |

## Setup
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/generate_sample_data.py                 # optional: refresh sample files to today's date
streamlit run app.py
python -m unittest discover -s tests -v                # 15 tests
```

## Brief → feature map
| Requirement | Where |
|---|---|
| Interactive interface | Streamlit sidebar app (`app.py`), terminal menu (`cli.py`) |
| Defensive validation | `core/validation.py` - names (regex), quantity 0-10,000, dates (3 formats, 2000-2100), expiry ≥ purchase, category/unit/location whitelist; **all errors reported at once**; CLI wrappers loop until valid |
| Core logic | `core/models.py` + `core/tracker.py` - status: Expired (<0 d), Critical (0-2), Expiring Soon (3-N, N configurable), Fresh |
| Persistence | `core/storage.py` - JSON or CSV, atomic writes, schema check per record, missing file → clean template, corrupt file → backed up + fresh start |
| Search / query | keyword + category + status + location filters (Inventory page, CLI option 6) |
| Executive summary | totals, averages (days left, shelf life, qty), status counts, per-category risk, riskiest category, 14-day expiry timeline, freshness score |
| Export (stretch) | Markdown, plain-text audit log, CSV report, Matplotlib PNG - `core/reports.py` |
| Warning indicators (stretch) | overdue, expires today, critical window, anomalous entries (qty > 1000 / shelf life > 5 yrs), **critical limit breach** when ≥ 40 % of pantry is at risk |
| GUI (stretch) | Streamlit dashboard with charts, forms, filters, downloads |
| Bulk import (stretch) | `core/tracker.py::import_csv` - header aliases (Item, Qty, Expiry Date…), duplicate skip, **row-by-row error log** |
| Sample data | `data/sample_pantry.csv/.json` (40 rows: normal, boundary, edge, anomaly) and `data/legacy_import_with_errors.csv` |

## 5-minute demo script
1. `streamlit run app.py` → branded dashboard → **Load 40 sample items**.
2. **Add Item**: blank name, quantity `-3`, expiry before purchase → all errors shown together; then fix and save.
3. **Dashboard**: metrics, warnings, trends, 14-day timeline. **Inventory**: search "milk", filter by status.
4. **Bulk Import** → tick the legacy demo file → read the row-by-row error log.
5. **Reports** → download Markdown/CSV, "Save all" shows the Matplotlib chart.
6. Stop the app, relaunch → data is still there (persistence). Settings → switch JSON ⇄ CSV.

## Layout
```
app.py  cli.py  core/{models,validation,storage,tracker,reports,sample_data}.py
data/   exports/   scripts/generate_sample_data.py   tests/test_core.py
```
Runtime data is stored in `data/pantry.json` (created automatically on first launch).
