"""Regenerate data/sample_pantry.csv|json (relative to today) and the legacy import demo file."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import sample_data as sd  # noqa: E402

root = Path(__file__).resolve().parents[1] / "data"
rows = sd.build_rows()
(root / "sample_pantry.csv").write_text(sd.to_csv(rows), encoding="utf-8")
(root / "sample_pantry.json").write_text(sd.to_json(rows), encoding="utf-8")
(root / "legacy_import_with_errors.csv").write_text(sd.legacy_import_sample(), encoding="utf-8")
print(f"Wrote {len(rows)} sample rows + legacy demo file to {root}")
