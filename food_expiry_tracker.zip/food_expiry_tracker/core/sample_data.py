"""Realistic seed data (40 rows) generated relative to 'today' so a demo is always lively.
Includes normal rows, boundary values and edge conditions."""
from __future__ import annotations

import csv
import io
import json
from datetime import date, timedelta

# name, category, qty, unit, location, bought_days_ago, days_until_expiry, notes
ROWS = [
    ("Whole Milk", "Dairy", 2, "L", "Fridge", 5, 2, "Boundary: critical window"),
    ("Greek Yogurt", "Dairy", 4, "pcs", "Fridge", 6, 4, ""),
    ("Cheddar Cheese", "Dairy", 0.5, "kg", "Fridge", 10, 25, ""),
    ("Butter", "Dairy", 250, "g", "Fridge", 12, 40, ""),
    ("Paneer", "Dairy", 400, "g", "Fridge", 4, -1, "Edge: expired yesterday"),
    ("Bananas", "Fruits", 6, "pcs", "Counter", 5, 1, ""),
    ("Apples", "Fruits", 1.5, "kg", "Fridge", 7, 12, ""),
    ("Strawberries", "Fruits", 1, "pack", "Fridge", 4, 0, "Edge: expires today"),
    ("Oranges", "Fruits", 8, "pcs", "Counter", 3, 9, ""),
    ("Spinach", "Vegetables", 300, "g", "Fridge", 6, -3, "Edge: overdue"),
    ("Tomatoes", "Vegetables", 1, "kg", "Counter", 3, 3, ""),
    ("Carrots", "Vegetables", 1, "kg", "Fridge", 8, 14, ""),
    ("Potatoes", "Vegetables", 5, "kg", "Pantry", 14, 30, ""),
    ("Onions", "Vegetables", 3, "kg", "Pantry", 10, 45, ""),
    ("Chicken Breast", "Meat & Fish", 800, "g", "Fridge", 3, 1, ""),
    ("Salmon Fillet", "Meat & Fish", 2, "pcs", "Fridge", 2, 0, "Cook today"),
    ("Frozen Prawns", "Frozen", 500, "g", "Freezer", 30, 120, ""),
    ("Sliced Bread", "Bakery", 1, "pack", "Counter", 4, 3, ""),
    ("Croissants", "Bakery", 4, "pcs", "Counter", 3, -2, "Edge: overdue"),
    ("Basmati Rice", "Grains & Pasta", 5, "kg", "Pantry", 40, 400, ""),
    ("Spaghetti", "Grains & Pasta", 2, "pack", "Cupboard", 60, 500, ""),
    ("Rolled Oats", "Grains & Pasta", 1, "kg", "Cupboard", 20, 180, ""),
    ("Chickpeas", "Canned & Jarred", 4, "can", "Pantry", 45, 600, ""),
    ("Tomato Passata", "Canned & Jarred", 3, "bottle", "Pantry", 30, 365, ""),
    ("Orange Juice", "Beverages", 1, "L", "Fridge", 6, 5, ""),
    ("Almond Milk", "Beverages", 2, "L", "Pantry", 15, 90, ""),
    ("Green Tea Bags", "Beverages", 100, "pcs", "Cupboard", 90, 700, "Boundary: large count"),
    ("Potato Chips", "Snacks", 3, "pack", "Cupboard", 20, 60, ""),
    ("Granola Bars", "Snacks", 12, "pcs", "Cupboard", 25, 150, ""),
    ("Peanut Butter", "Condiments & Sauces", 1, "bottle", "Pantry", 50, 300, ""),
    ("Soy Sauce", "Condiments & Sauces", 500, "ml", "Pantry", 80, 450, ""),
    ("Ketchup", "Condiments & Sauces", 1, "bottle", "Fridge", 35, 8, "Boundary: 8 days"),
    ("Frozen Peas", "Frozen", 1, "kg", "Freezer", 20, 200, ""),
    ("Ice Cream", "Frozen", 1, "box", "Freezer", 15, 7, "Boundary: exactly 7 days"),
    ("Hummus", "Other", 200, "g", "Fridge", 5, 6, ""),
    ("Saffron Threads", "Other", 0.01, "kg", "Cupboard", 100, 900, "Boundary: tiny quantity"),
    ("Bulk Rice Sack", "Grains & Pasta", 10000, "kg", "Pantry", 5, 365, "Boundary: max quantity"),
    ("Honey Jar", "Condiments & Sauces", 1, "bottle", "Pantry", 10, 2200, "Anomaly: >5 year shelf life"),
    ("Eggs", "Dairy", 12, "pcs", "Fridge", 8, 10, ""),
    ("Mushrooms", "Vegetables", 250, "g", "Fridge", 4, 2, ""),
]


def build_rows(today: date | None = None) -> list[dict]:
    today = today or date.today()
    return [{"name": n, "category": c, "quantity": q, "unit": u, "location": loc,
             "purchase_date": (today - timedelta(days=b)).isoformat(),
             "expiry_date": (today + timedelta(days=e)).isoformat(), "notes": notes}
            for n, c, q, u, loc, b, e, notes in ROWS]


def to_csv(rows: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=["name", "category", "quantity", "unit",
                                        "purchase_date", "expiry_date", "location", "notes"])
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue()


def to_json(rows: list[dict]) -> str:
    return json.dumps({"items": rows}, indent=2)


LEGACY_BAD_CSV = """Item,Category,Qty,Expiry Date,Storage
Cottage Cheese,Dairy,2,{d1},Fridge
,Dairy,1,{d1},Fridge
Mango,Fruits,abc,{d1},Counter
Mystery Box,Gadgets,1,{d1},Pantry
Lettuce,Vegetables,1,31/02/2027,Fridge
Pasta Sauce,Canned & Jarred,-3,{d1},Pantry
Brown Rice,Grains & Pasta,2,{d2},Pantry
Brown Rice,Grains & Pasta,2,{d2},Pantry
"""


def legacy_import_sample(today: date | None = None) -> str:
    today = today or date.today()
    return LEGACY_BAD_CSV.format(d1=(today + timedelta(days=6)).isoformat(),
                                 d2=(today + timedelta(days=200)).isoformat())
