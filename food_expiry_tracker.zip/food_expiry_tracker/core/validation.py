"""Defensive input validation. Every function either returns a clean value
or raises ValidationError carrying a list of human-readable messages."""
from __future__ import annotations

import math
import re
from datetime import date, datetime

from .models import CATEGORIES, LOCATIONS, UNITS, Item

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 '&().,/\-]{0,59}$")
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y")
MAX_QTY = 10_000
MAX_SHELF_LIFE_DAYS = 365 * 5
MIN_YEAR, MAX_YEAR = 2000, 2100


class ValidationError(ValueError):
    def __init__(self, errors):
        self.errors = [errors] if isinstance(errors, str) else list(errors)
        super().__init__("; ".join(self.errors))


def clean_name(raw) -> str:
    s = re.sub(r"\s+", " ", str(raw or "")).strip()
    if not s:
        raise ValidationError("Name cannot be blank.")
    if not NAME_RE.match(s):
        raise ValidationError("Name must be 1-60 chars, start with a letter/digit and "
                              "use only letters, digits and basic punctuation.")
    return s


def clean_choice(raw, options, label: str) -> str:
    s = str(raw or "").strip()
    for opt in options:
        if s.lower() == opt.lower():
            return opt
    raise ValidationError(f"{label} must be one of: {', '.join(options)}.")


def clean_quantity(raw) -> float:
    if isinstance(raw, bool) or raw is None or str(raw).strip() == "":
        raise ValidationError("Quantity is required and must be a number.")
    try:
        q = float(str(raw).strip().replace(",", ""))
    except ValueError:
        raise ValidationError(f"Quantity '{raw}' is not a number.") from None
    if math.isnan(q) or math.isinf(q):
        raise ValidationError("Quantity must be a finite number.")
    if q <= 0:
        raise ValidationError("Quantity must be greater than 0.")
    if q > MAX_QTY:
        raise ValidationError(f"Quantity cannot exceed {MAX_QTY:,}.")
    return round(q, 3)


def parse_date(raw, label: str = "Date") -> date:
    if isinstance(raw, datetime):
        raw = raw.date()
    if isinstance(raw, date):
        d = raw
    else:
        s = str(raw or "").strip()
        if not s:
            raise ValidationError(f"{label} is required (YYYY-MM-DD).")
        d = None
        for fmt in DATE_FORMATS:
            try:
                d = datetime.strptime(s, fmt).date()
                break
            except ValueError:
                continue
        if d is None:
            raise ValidationError(f"{label} '{s}' is not a valid date. Use YYYY-MM-DD.")
    if not MIN_YEAR <= d.year <= MAX_YEAR:
        raise ValidationError(f"{label} year must be between {MIN_YEAR} and {MAX_YEAR}.")
    return d


def build_item(raw: dict, today: date | None = None, item_id: str = "") -> tuple[Item, list[str]]:
    """Validate a raw record. Returns (Item, warnings); raises ValidationError
    containing *all* problems found (so the UI can show them at once)."""
    today = today or date.today()
    errors: list[str] = []

    def attempt(fn, *args):
        try:
            return fn(*args)
        except ValidationError as e:
            errors.extend(e.errors)
            return None

    name = attempt(clean_name, raw.get("name"))
    category = attempt(clean_choice, raw.get("category"), CATEGORIES, "Category")
    qty = attempt(clean_quantity, raw.get("quantity"))
    unit = attempt(clean_choice, raw.get("unit") or "pcs", UNITS, "Unit")
    location = attempt(clean_choice, raw.get("location") or "Pantry", LOCATIONS, "Location")
    p_raw = raw.get("purchase_date")
    purchase = today if p_raw in (None, "") else attempt(parse_date, p_raw, "Purchase date")
    expiry = attempt(parse_date, raw.get("expiry_date"), "Expiry date")
    notes = re.sub(r"[\x00-\x1f\x7f]", " ", str(raw.get("notes") or "")).strip()
    if len(notes) > 200:
        errors.append("Notes cannot exceed 200 characters.")
    if purchase and expiry and expiry < purchase:
        errors.append("Expiry date cannot be before the purchase date.")
    if errors:
        raise ValidationError(errors)

    warnings: list[str] = []
    if purchase > today:
        warnings.append("Purchase date is in the future.")
    if (expiry - purchase).days > MAX_SHELF_LIFE_DAYS:
        warnings.append("Shelf life exceeds 5 years - please double-check the expiry date.")
    if qty > 1000:
        warnings.append("Unusually large quantity (>1000).")
    if expiry < today:
        warnings.append("This item is already expired.")
    return Item(name, category, qty, unit, purchase, expiry, location, notes, item_id), warnings
