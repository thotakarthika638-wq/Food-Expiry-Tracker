"""Data model for a pantry item plus domain constants."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date

CATEGORIES = [
    "Dairy", "Fruits", "Vegetables", "Meat & Fish", "Bakery", "Grains & Pasta",
    "Canned & Jarred", "Beverages", "Snacks", "Frozen", "Condiments & Sauces", "Other",
]
UNITS = ["pcs", "kg", "g", "L", "ml", "pack", "can", "bottle", "box"]
LOCATIONS = ["Pantry", "Fridge", "Freezer", "Counter", "Cupboard"]

EXPIRED, CRITICAL, SOON, FRESH = "Expired", "Critical", "Expiring Soon", "Fresh"
STATUS_ORDER = [EXPIRED, CRITICAL, SOON, FRESH]
CRITICAL_DAYS = 2          # 0..2 days left  -> Critical
DEFAULT_WARN_DAYS = 7      # 3..7 days left  -> Expiring Soon

FIELDS = ["id", "name", "category", "quantity", "unit", "purchase_date",
          "expiry_date", "location", "notes"]


def new_id() -> str:
    return uuid.uuid4().hex[:8]


@dataclass
class Item:
    name: str
    category: str
    quantity: float
    unit: str
    purchase_date: date
    expiry_date: date
    location: str = "Pantry"
    notes: str = ""
    id: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            self.id = new_id()

    def days_left(self, today: date | None = None) -> int:
        return (self.expiry_date - (today or date.today())).days

    def shelf_life(self) -> int:
        return (self.expiry_date - self.purchase_date).days

    def status(self, today: date | None = None, warn_days: int = DEFAULT_WARN_DAYS) -> str:
        d = self.days_left(today)
        if d < 0:
            return EXPIRED
        if d <= CRITICAL_DAYS:
            return CRITICAL
        if d <= warn_days:
            return SOON
        return FRESH

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "category": self.category,
            "quantity": self.quantity, "unit": self.unit,
            "purchase_date": self.purchase_date.isoformat(),
            "expiry_date": self.expiry_date.isoformat(),
            "location": self.location, "notes": self.notes,
        }
