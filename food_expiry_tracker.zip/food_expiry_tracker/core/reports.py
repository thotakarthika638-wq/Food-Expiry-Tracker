"""Multi-format report export: Markdown, plain-text audit log, CSV, optional PNG chart."""
from __future__ import annotations

import csv
import io
from datetime import date, datetime
from pathlib import Path

from .models import STATUS_ORDER
from .tracker import Tracker


def _rows(t: Tracker, today: date):
    return [(i, i.days_left(today), t.status_of(i, today))
            for i in sorted(t.items, key=lambda x: x.expiry_date)]


def to_markdown(t: Tracker, today: date | None = None) -> str:
    today = today or date.today()
    s = t.summary(today)
    L = [f"# FreshKeep - Pantry Expiry Report", f"_Generated for {today.isoformat()}_", "",
         "## Executive Summary", "",
         f"- **Total items:** {s['total_items']}",
         f"- **Freshness score:** {s['freshness_score']}/100",
         f"- **At risk (expired or expiring within {t.warn_days} days):** "
         f"{s['at_risk']} ({s['at_risk_pct']}%)",
         f"- **Average days left (unexpired):** {s['avg_days_left']}",
         f"- **Average shelf life:** {s['avg_shelf_life']} days",
         f"- **Riskiest category:** {s['riskiest_category']} ({s['riskiest_category_pct']}% at risk)",
         f"- **Soonest to expire:** {s['soonest_item']}", "",
         "## Status Breakdown", "", "| Status | Items |", "|---|---:|"]
    L += [f"| {k} | {v} |" for k, v in s["status_counts"].items()]
    L += ["", "## Category Analysis", "",
          "| Category | Items | At risk | Risk % | Avg qty |", "|---|---:|---:|---:|---:|"]
    L += [f"| {c} | {v['items']} | {v['at_risk']} | {v['risk_pct']} | {v['avg_quantity']} |"
          for c, v in s["category_stats"].items()]
    alerts = t.alerts(today)
    L += ["", "## Warnings", ""] + ([f"- **{a['level'].upper()}** {a['message']}" for a in alerts]
                                    or ["- None"])
    L += ["", "## Full Inventory", "",
          "| Name | Category | Qty | Location | Expiry | Days left | Status |",
          "|---|---|---:|---|---|---:|---|"]
    L += [f"| {i.name} | {i.category} | {i.quantity:g} {i.unit} | {i.location} | "
          f"{i.expiry_date} | {d} | {st} |" for i, d, st in _rows(t, today)]
    return "\n".join(L) + "\n"


def to_text_audit(t: Tracker, today: date | None = None) -> str:
    today = today or date.today()
    s = t.summary(today)
    bar = "=" * 78
    L = [bar, "FRESHKEEP AUDIT LOG", f"Generated : {datetime.now():%Y-%m-%d %H:%M:%S}",
         f"As of date: {today.isoformat()}", f"Data file : {t.path}", bar,
         f"Total items ........ {s['total_items']}",
         f"Freshness score .... {s['freshness_score']}/100",
         f"At risk ............ {s['at_risk']} ({s['at_risk_pct']}%)",
         f"Avg days left ...... {s['avg_days_left']}", "", "STATUS COUNTS"]
    L += [f"  {k:<14}{v}" for k, v in s["status_counts"].items()]
    L += ["", "WARNINGS"] + ([f"  [{a['level'].upper():8}] {a['message']}" for a in t.alerts(today)]
                             or ["  none"])
    L += ["", "INVENTORY", f"  {'ID':<9}{'NAME':<24}{'EXPIRY':<12}{'DAYS':>5}  STATUS"]
    L += [f"  {i.id:<9}{i.name[:23]:<24}{i.expiry_date!s:<12}{d:>5}  {st}"
          for i, d, st in _rows(t, today)]
    if t.load_issues:
        L += ["", "LOAD ISSUES"] + [f"  - {m}" for m in t.load_issues]
    return "\n".join(L + [bar]) + "\n"


def to_csv_report(t: Tracker, today: date | None = None) -> str:
    today = today or date.today()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "name", "category", "quantity", "unit", "location", "purchase_date",
                "expiry_date", "days_left", "status", "notes"])
    for i, d, st in _rows(t, today):
        w.writerow([i.id, i.name, i.category, i.quantity, i.unit, i.location,
                    i.purchase_date, i.expiry_date, d, st, i.notes])
    return buf.getvalue()


def save_status_chart(t: Tracker, path, today: date | None = None) -> bool:
    """Matplotlib bar chart of status counts. Returns False if matplotlib is unavailable."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False
    s = t.summary(today)
    colors = {"Expired": "#e5484d", "Critical": "#f76b15", "Expiring Soon": "#f5a524", "Fresh": "#30a46c"}
    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.bar(STATUS_ORDER, [s["status_counts"][k] for k in STATUS_ORDER],
           color=[colors[k] for k in STATUS_ORDER])
    ax.set_title("Pantry freshness status")
    ax.set_ylabel("Items")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return True


def export_all(t: Tracker, folder="exports", today: date | None = None) -> list[Path]:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = (today or date.today()).isoformat()
    out = []
    for name, text in ((f"report_{stamp}.md", to_markdown(t, today)),
                       (f"audit_{stamp}.txt", to_text_audit(t, today)),
                       (f"report_{stamp}.csv", to_csv_report(t, today))):
        p = folder / name
        p.write_text(text, encoding="utf-8", newline="")
        out.append(p)
    png = folder / f"status_chart_{stamp}.png"
    if save_status_chart(t, png, today):
        out.append(png)
    return out
