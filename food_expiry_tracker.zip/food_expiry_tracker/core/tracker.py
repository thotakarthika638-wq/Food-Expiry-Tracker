"""Business-logic engine: CRUD, search, expiry detection, alerts, summary, bulk import."""
from __future__ import annotations

import csv
import io
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from statistics import mean

from .models import DEFAULT_WARN_DAYS, FRESH, STATUS_ORDER, Item, new_id
from .storage import load_items, save_items
from .validation import MAX_SHELF_LIFE_DAYS, ValidationError, build_item

HEADER_ALIASES = {
    "item": "name", "item_name": "name", "product": "name",
    "qty": "quantity", "amount": "quantity",
    "expiry": "expiry_date", "expiry date": "expiry_date", "expires": "expiry_date",
    "exp_date": "expiry_date", "best_before": "expiry_date",
    "purchase": "purchase_date", "purchased": "purchase_date", "bought": "purchase_date",
    "storage": "location", "storage_location": "location",
}
REQUIRED_COLUMNS = ["name", "category", "quantity", "expiry_date"]
RISK_BREACH_PCT = 40.0


@dataclass
class ImportResult:
    total_rows: int = 0
    added: int = 0
    duplicates: int = 0
    errors: list = field(default_factory=list)      # (row_number, message)
    warnings: list = field(default_factory=list)    # (row_number, message)
    fatal: str = ""

    def error_log(self) -> str:
        lines = [f"Import report: {self.added} added, {self.duplicates} duplicates skipped, "
                 f"{len(self.errors)} rows rejected of {self.total_rows}."]
        if self.fatal:
            lines.append(f"FATAL: {self.fatal}")
        lines += [f"Row {n}: ERROR - {m}" for n, m in self.errors]
        lines += [f"Row {n}: WARNING - {m}" for n, m in self.warnings]
        return "\n".join(lines)


class Tracker:
    def __init__(self, path="data/pantry.json", warn_days: int = DEFAULT_WARN_DAYS):
        self.path = Path(path)
        self.warn_days = warn_days
        self.items: list[Item] = []
        self.load_issues: list[str] = []
        self.reload()

    # ---------- persistence ----------
    def reload(self) -> None:
        self.items, self.load_issues = load_items(self.path)

    def save(self) -> None:
        save_items(self.path, self.items)

    def switch_file(self, new_path) -> None:
        self.path = Path(new_path)
        self.save()

    # ---------- CRUD ----------
    def get(self, item_id: str) -> Item | None:
        return next((i for i in self.items if i.id == item_id), None)

    def add(self, raw: dict, today: date | None = None) -> tuple[Item, list[str]]:
        item, warnings = build_item(raw, today)
        self.items.append(item)
        self.save()
        return item, warnings

    def update(self, item_id: str, raw: dict, today: date | None = None) -> tuple[Item, list[str]]:
        old = self.get(item_id)
        if old is None:
            raise ValidationError(f"No item with id {item_id}.")
        item, warnings = build_item(raw, today, item_id=item_id)
        self.items[self.items.index(old)] = item
        self.save()
        return item, warnings

    def delete(self, item_id: str) -> bool:
        item = self.get(item_id)
        if item is None:
            return False
        self.items.remove(item)
        self.save()
        return True

    def clear(self) -> None:
        self.items = []
        self.save()

    # ---------- query & search ----------
    def status_of(self, item: Item, today: date | None = None) -> str:
        return item.status(today, self.warn_days)

    def search(self, keyword: str = "", categories=None, statuses=None, locations=None,
               today: date | None = None) -> list[Item]:
        kw = (keyword or "").strip().lower()
        out = []
        for i in self.items:
            if kw and kw not in f"{i.name} {i.category} {i.location} {i.notes}".lower():
                continue
            if categories and i.category not in categories:
                continue
            if locations and i.location not in locations:
                continue
            if statuses and self.status_of(i, today) not in statuses:
                continue
            out.append(i)
        return sorted(out, key=lambda x: x.expiry_date)

    def expiring_within(self, days: int, today: date | None = None) -> list[Item]:
        return sorted((i for i in self.items if 0 <= i.days_left(today) <= days),
                      key=lambda x: x.expiry_date)

    def expired(self, today: date | None = None) -> list[Item]:
        return sorted((i for i in self.items if i.days_left(today) < 0),
                      key=lambda x: x.expiry_date)

    # ---------- alerts ----------
    def alerts(self, today: date | None = None) -> list[dict]:
        today = today or date.today()
        out = []
        for i in sorted(self.items, key=lambda x: x.expiry_date):
            d, tag = i.days_left(today), f"{i.name} ({i.quantity:g} {i.unit}, {i.location})"
            if d < 0:
                out.append({"level": "critical", "item_id": i.id,
                            "message": f"OVERDUE: {tag} expired {-d} day(s) ago."})
            elif d == 0:
                out.append({"level": "critical", "item_id": i.id,
                            "message": f"EXPIRES TODAY: {tag}."})
            elif d <= self.warn_days:
                lvl = "critical" if d <= 2 else "warning"
                out.append({"level": lvl, "item_id": i.id,
                            "message": f"{tag} expires in {d} day(s)."})
        for i in self.items:
            if i.shelf_life() > MAX_SHELF_LIFE_DAYS or i.quantity > 1000:
                out.append({"level": "info", "item_id": i.id,
                            "message": f"Anomalous entry: {i.name} "
                                       f"(qty {i.quantity:g}, shelf life {i.shelf_life()} days)."})
        s = self.summary(today)
        if s["total_items"] and s["at_risk_pct"] >= RISK_BREACH_PCT:
            out.insert(0, {"level": "critical", "item_id": "",
                           "message": f"CRITICAL LIMIT BREACH: {s['at_risk_pct']}% of your pantry "
                                      f"is expired or expiring within {self.warn_days} days."})
        return out

    # ---------- executive summary ----------
    def summary(self, today: date | None = None) -> dict:
        today = today or date.today()
        items = self.items
        n = len(items)
        statuses = Counter(self.status_of(i, today) for i in items)
        status_counts = {s: statuses.get(s, 0) for s in STATUS_ORDER}
        at_risk = n - status_counts[FRESH]
        active = [i for i in items if i.days_left(today) >= 0]
        cat_stats = {}
        for c in sorted({i.category for i in items}):
            ci = [i for i in items if i.category == c]
            risk = sum(1 for i in ci if self.status_of(i, today) != FRESH)
            cat_stats[c] = {"items": len(ci), "at_risk": risk,
                            "risk_pct": round(100 * risk / len(ci), 1),
                            "avg_quantity": round(mean(i.quantity for i in ci), 2)}
        riskiest = max(cat_stats.items(), key=lambda kv: (kv[1]["risk_pct"], kv[1]["items"]),
                       default=(None, None))
        timeline = {(today + timedelta(days=k)).isoformat():
                    sum(1 for i in items if i.days_left(today) == k) for k in range(15)}
        soonest = min(active, key=lambda i: i.days_left(today), default=None)
        return {
            "as_of": today.isoformat(),
            "total_items": n,
            "total_quantity_by_unit": {u: round(sum(i.quantity for i in items if i.unit == u), 3)
                                       for u in sorted({i.unit for i in items})},
            "avg_quantity": round(mean(i.quantity for i in items), 2) if n else 0,
            "avg_days_left": round(mean(i.days_left(today) for i in active), 1) if active else None,
            "avg_shelf_life": round(mean(i.shelf_life() for i in items), 1) if n else None,
            "status_counts": status_counts,
            "at_risk": at_risk,
            "at_risk_pct": round(100 * at_risk / n, 1) if n else 0.0,
            "freshness_score": round(100 * status_counts[FRESH] / n) if n else 0,
            "category_stats": cat_stats,
            "location_counts": dict(Counter(i.location for i in items)),
            "riskiest_category": riskiest[0],
            "riskiest_category_pct": riskiest[1]["risk_pct"] if riskiest[1] else 0,
            "soonest_item": (f"{soonest.name} ({soonest.days_left(today)} day(s))"
                             if soonest else None),
            "expiry_timeline_14d": timeline,
        }

    # ---------- bulk import ----------
    def import_csv(self, text: str, today: date | None = None,
                   skip_duplicates: bool = True) -> ImportResult:
        res = ImportResult()
        text = text.lstrip("\ufeff")
        try:
            reader = csv.DictReader(io.StringIO(text))
            headers = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
        except csv.Error as exc:
            res.fatal = f"Could not parse CSV: {exc}"
            return res
        mapped = [HEADER_ALIASES.get(h, h) for h in headers]
        missing = [c for c in REQUIRED_COLUMNS if c not in mapped]
        if missing:
            res.fatal = f"Missing required column(s): {', '.join(missing)}."
            return res
        reader.fieldnames = mapped
        existing = {(i.name.lower(), i.expiry_date, i.location) for i in self.items}
        try:
            for n, row in enumerate(reader, start=2):      # row 1 is the header
                res.total_rows += 1
                if None in row:
                    res.errors.append((n, "Too many columns in this row."))
                    continue
                if not any((v or "").strip() for v in row.values()):
                    res.total_rows -= 1
                    continue
                try:
                    item, warns = build_item({k: (v or "") for k, v in row.items()}, today)
                except ValidationError as e:
                    res.errors.append((n, "; ".join(e.errors)))
                    continue
                key = (item.name.lower(), item.expiry_date, item.location)
                if skip_duplicates and key in existing:
                    res.duplicates += 1
                    continue
                existing.add(key)
                item.id = new_id()
                self.items.append(item)
                res.added += 1
                res.warnings += [(n, w) for w in warns]
        except csv.Error as exc:
            res.fatal = f"CSV parsing stopped early: {exc}"
        if res.added:
            self.save()
        return res
