"""Local persistence (JSON or CSV) with schema checks and corruption recovery."""
from __future__ import annotations

import csv
import io
import json
import os
import shutil
import tempfile
import time
from pathlib import Path

from .models import FIELDS, Item, new_id
from .validation import ValidationError, build_item


def _write_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def save_items(path, items: list[Item]) -> None:
    path = Path(path)
    rows = [i.to_dict() for i in items]
    if path.suffix.lower() == ".csv":
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
        _write_atomic(path, buf.getvalue())
    else:
        _write_atomic(path, json.dumps({"version": 1, "items": rows}, indent=2))


def _backup_corrupt(path: Path) -> str:
    dest = path.with_name(f"{path.name}.corrupt-{int(time.time())}")
    shutil.copy2(path, dest)
    return dest.name


def load_items(path) -> tuple[list[Item], list[str]]:
    """Return (items, issues). Never raises for missing/corrupt/invalid files:
    a clean template is created and problems are reported in `issues`."""
    path = Path(path)
    issues: list[str] = []
    rows: list[dict] = []
    try:
        text = path.read_text(encoding="utf-8")
        if path.suffix.lower() == ".csv":
            rows = list(csv.DictReader(text.splitlines()))
        else:
            data = json.loads(text)
            rows = data.get("items", []) if isinstance(data, dict) else data
            if not isinstance(rows, list):
                raise json.JSONDecodeError("items must be a list", text, 0)
    except FileNotFoundError:
        save_items(path, [])
        return [], [f"No data file found - created a clean template at {path.name}."]
    except (json.JSONDecodeError, UnicodeDecodeError, csv.Error) as exc:
        saved = _backup_corrupt(path)
        save_items(path, [])
        return [], [f"Data file was unreadable ({exc.__class__.__name__}). "
                    f"Backed up as {saved} and started fresh."]

    items, seen = [], set()
    for n, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            issues.append(f"Record {n}: not an object - skipped.")
            continue
        try:
            item, _ = build_item(row, item_id=str(row.get("id") or ""))
        except ValidationError as e:
            issues.append(f"Record {n}: {'; '.join(e.errors)} - skipped.")
            continue
        if item.id in seen:
            item.id = new_id()
        seen.add(item.id)
        items.append(item)
    return items, issues
