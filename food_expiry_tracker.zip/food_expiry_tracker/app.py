"""FreshKeep - modern Streamlit interface for the Food Expiry Tracker.
Run:  streamlit run app.py
"""
from __future__ import annotations

import io
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

from core import CATEGORIES, LOCATIONS, UNITS, Tracker, ValidationError, reports, sample_data
from core.models import CRITICAL, EXPIRED, FRESH, SOON, STATUS_ORDER

ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
EXPORT_DIR = ROOT / "exports"
BADGE = {EXPIRED: "🔴 Expired", CRITICAL: "🟠 Critical", SOON: "🟡 Expiring Soon", FRESH: "🟢 Fresh"}
PAGES = ["📊 Dashboard", "➕ Add Item", "📦 Inventory", "⏰ Alerts", "🧾 Reports",
         "📥 Bulk Import", "⚙️ Settings"]

st.set_page_config(page_title="FreshKeep | Food Expiry Tracker", page_icon="🥗", layout="wide")
st.markdown("""
<style>
.hero{padding:1.4rem 1.8rem;border-radius:18px;margin-bottom:1.2rem;color:#fff;
      background:linear-gradient(120deg,#12b886 0%,#2f9e44 45%,#1c7ed6 100%);}
.hero h1{margin:0;font-size:2rem;color:#fff;} .hero p{margin:.25rem 0 0;opacity:.92;}
[data-testid="stMetric"]{background:rgba(128,128,128,.10);border:1px solid rgba(128,128,128,.18);
      padding:.9rem 1rem;border-radius:14px;}
div[data-testid="stForm"]{border-radius:16px;}
.stButton>button,.stDownloadButton>button{border-radius:10px;font-weight:600;}
</style>
""", unsafe_allow_html=True)

ss = st.session_state
ss.setdefault("warn_days", 7)
ss.setdefault("data_file", "pantry.json")
tracker = Tracker(DATA_DIR / ss.data_file, ss.warn_days)
today = date.today()


# ------------------------------------------------------------------ helpers
def to_df(items) -> pd.DataFrame:
    return pd.DataFrame([{
        "ID": i.id, "Name": i.name, "Category": i.category,
        "Qty": f"{i.quantity:g} {i.unit}", "Location": i.location,
        "Purchased": i.purchase_date.isoformat(), "Expires": i.expiry_date.isoformat(),
        "Days left": i.days_left(today), "Status": BADGE[tracker.status_of(i, today)],
        "Notes": i.notes,
    } for i in items], columns=["ID", "Name", "Category", "Qty", "Location", "Purchased",
                                "Expires", "Days left", "Status", "Notes"])


def show_table(items, height=None):
    if not items:
        st.info("Nothing to show here.")
        return
    st.dataframe(to_df(items), hide_index=True, height=height)


def show_alert_list(alerts, limit=None):
    if not alerts:
        st.success("All clear - nothing needs attention. 🎉")
        return
    for a in alerts[:limit]:
        {"critical": st.error, "warning": st.warning, "info": st.info}[a["level"]](a["message"])


def show_validation(errors):
    for e in errors:
        st.error(e, icon="🚫")


def load_sample(replace=False):
    if replace:
        tracker.clear()
    return tracker.import_csv(sample_data.to_csv(sample_data.build_rows(today)), today)


def item_form(key: str, item=None):
    """Shared Add/Edit form. Returns (submitted, raw_dict)."""
    d = item.to_dict() if item else {}
    c1, c2, c3 = st.columns([2, 1.3, 1])
    name = c1.text_input("Item name *", value=d.get("name", ""), placeholder="e.g. Greek Yogurt")
    category = c2.selectbox("Category *", CATEGORIES,
                            index=CATEGORIES.index(d["category"]) if d else 0)
    location = c3.selectbox("Location", LOCATIONS,
                            index=LOCATIONS.index(d["location"]) if d else 0)
    q1, q2, q3, q4 = st.columns([1, 1, 1.3, 1.3])
    qty = q1.number_input("Quantity *", value=float(d.get("quantity", 1.0)), step=0.5, format="%.2f")
    unit = q2.selectbox("Unit", UNITS, index=UNITS.index(d["unit"]) if d else 0)
    purchase = q3.date_input("Purchase date", value=item.purchase_date if item else today,
                             min_value=date(2000, 1, 1), max_value=date(2100, 12, 31))
    expiry = q4.date_input("Expiry date *", value=item.expiry_date if item else today + timedelta(days=7),
                           min_value=date(2000, 1, 1), max_value=date(2100, 12, 31))
    notes = st.text_input("Notes", value=d.get("notes", ""), placeholder="optional")
    submitted = st.form_submit_button("Save changes" if item else "Add to pantry",
                                      type="primary")
    return submitted, dict(name=name, category=category, quantity=qty, unit=unit, location=location,
                           purchase_date=purchase, expiry_date=expiry, notes=notes)


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.markdown("## 🥗 FreshKeep")
    st.caption("Food Expiry Tracker · StudentLife Hack #62")
    page = st.radio("Navigate", PAGES, label_visibility="collapsed")
    st.divider()
    s_side = tracker.summary(today)
    st.caption("Pantry freshness")
    st.progress(s_side["freshness_score"] / 100, text=f"{s_side['freshness_score']}/100")
    st.caption(f"{s_side['total_items']} items · {s_side['at_risk']} need attention")
    if tracker.load_issues:
        with st.expander(f"⚠️ {len(tracker.load_issues)} load notice(s)"):
            for m in tracker.load_issues[:20]:
                st.write("• " + m)

st.markdown(f"""<div class="hero"><h1>{page}</h1>
<p>Know what's in your kitchen, use it before it expires, and waste less. · {today:%A, %d %B %Y}</p></div>""",
            unsafe_allow_html=True)

# ------------------------------------------------------------------ Dashboard
if page == PAGES[0]:
    if not tracker.items:
        st.info("Your pantry is empty. Add an item, import a CSV, or load realistic demo data.")
        if st.button("✨ Load 40 sample items", type="primary"):
            r = load_sample()
            st.toast(f"Loaded {r.added} items")
            st.rerun()
    else:
        s = tracker.summary(today)
        sc = s["status_counts"]
        m = st.columns(5)
        m[0].metric("Total items", s["total_items"])
        m[1].metric("Expired", sc[EXPIRED])
        m[2].metric("Critical (≤2 days)", sc[CRITICAL])
        m[3].metric(f"Soon (≤{tracker.warn_days} days)", sc[SOON])
        m[4].metric("Avg days left", s["avg_days_left"] if s["avg_days_left"] is not None else "-")

        left, right = st.columns([1.1, 1])
        with left:
            st.subheader("Top warnings")
            show_alert_list(tracker.alerts(today), limit=5)
        with right:
            st.subheader("Key trends")
            st.markdown(
                f"- **Freshness score:** {s['freshness_score']}/100\n"
                f"- **At risk:** {s['at_risk']} items ({s['at_risk_pct']}%)\n"
                f"- **Riskiest category:** {s['riskiest_category']} "
                f"({s['riskiest_category_pct']}% at risk)\n"
                f"- **Soonest to expire:** {s['soonest_item']}\n"
                f"- **Average shelf life:** {s['avg_shelf_life']} days")

        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Status distribution")
            st.bar_chart(pd.DataFrame({"Items": [sc[k] for k in STATUS_ORDER]}, index=STATUS_ORDER))
        with c2:
            st.subheader("Items by category")
            st.bar_chart(pd.DataFrame({"Items": {c: v["items"] for c, v in s["category_stats"].items()}}))

        st.subheader("Expiry timeline - next 14 days")
        tl = pd.DataFrame({"Items expiring": list(s["expiry_timeline_14d"].values())},
                          index=list(s["expiry_timeline_14d"].keys()))
        st.bar_chart(tl)

        st.subheader("Use these first")
        show_table(tracker.expiring_within(tracker.warn_days, today))

# ------------------------------------------------------------------ Add item
elif page == PAGES[1]:
    st.caption("Every field is validated before it is saved; all problems are shown at once.")
    with st.form("add_form", clear_on_submit=False):
        submitted, raw = item_form("add")
    if submitted:
        try:
            item, warns = tracker.add(raw, today)
            st.success(f"Added **{item.name}** (id `{item.id}`) - {item.days_left(today)} day(s) left.")
            for w in warns:
                st.warning(w)
            st.toast("Saved to pantry ✅")
        except ValidationError as e:
            show_validation(e.errors)

# ------------------------------------------------------------------ Inventory
elif page == PAGES[2]:
    f1, f2, f3, f4 = st.columns([2, 1.4, 1.4, 1.2])
    kw = f1.text_input("🔍 Search", placeholder="name, category, location, notes…")
    cats = f2.multiselect("Category", CATEGORIES)
    stats = f3.multiselect("Status", STATUS_ORDER)
    locs = f4.multiselect("Location", LOCATIONS)
    results = tracker.search(kw, cats, stats, locs, today)
    st.caption(f"{len(results)} of {len(tracker.items)} items")
    show_table(results, height=420)
    if results:
        st.download_button("⬇️ Download filtered CSV", to_df(results).to_csv(index=False),
                           file_name="pantry_filtered.csv", mime="text/csv")

        st.subheader("Manage an item")
        labels = {i.id: f"{i.name} · expires {i.expiry_date} ({i.id})" for i in results}
        chosen = st.selectbox("Select item", list(labels), format_func=labels.get)
        item = tracker.get(chosen)
        tab_edit, tab_del = st.tabs(["✏️ Edit", "🗑️ Delete / mark consumed"])
        with tab_edit:
            with st.form(f"edit_{chosen}"):
                submitted, raw = item_form(f"edit_{chosen}", item)
            if submitted:
                try:
                    tracker.update(chosen, raw, today)
                    st.success("Updated.")
                    st.rerun()
                except ValidationError as e:
                    show_validation(e.errors)
        with tab_del:
            st.write(f"Remove **{item.name}** from the pantry?")
            if st.button("Delete item", type="primary", key=f"del_{chosen}"):
                tracker.delete(chosen)
                st.toast("Item removed")
                st.rerun()

# ------------------------------------------------------------------ Alerts
elif page == PAGES[3]:
    alerts = tracker.alerts(today)
    a = st.columns(3)
    a[0].metric("Critical", sum(x["level"] == "critical" for x in alerts))
    a[1].metric("Warnings", sum(x["level"] == "warning" for x in alerts))
    a[2].metric("Anomalies", sum(x["level"] == "info" for x in alerts))
    show_alert_list(alerts)
    st.divider()
    days = st.slider("Show items expiring within (days)", 1, 60, tracker.warn_days)
    st.subheader(f"Expiring in the next {days} days")
    show_table(tracker.expiring_within(days, today))
    st.subheader("Already expired")
    show_table(tracker.expired(today))

# ------------------------------------------------------------------ Reports
elif page == PAGES[4]:
    if not tracker.items:
        st.info("Add some items first to generate reports.")
    else:
        s = tracker.summary(today)
        k = st.columns(4)
        k[0].metric("Freshness score", f"{s['freshness_score']}/100")
        k[1].metric("At risk", f"{s['at_risk_pct']}%")
        k[2].metric("Avg shelf life", f"{s['avg_shelf_life']} d")
        k[3].metric("Avg quantity", s["avg_quantity"])
        st.subheader("Category analysis")
        st.dataframe(pd.DataFrame(s["category_stats"]).T.rename(columns={
            "items": "Items", "at_risk": "At risk", "risk_pct": "Risk %", "avg_quantity": "Avg qty"}))
        st.subheader("Total quantity by unit")
        st.dataframe(pd.DataFrame({"Total": s["total_quantity_by_unit"]}))

        md, txt, csv_text = (reports.to_markdown(tracker, today), reports.to_text_audit(tracker, today),
                             reports.to_csv_report(tracker, today))
        st.subheader("Export")
        d = st.columns(4)
        d[0].download_button("⬇️ Markdown", md, f"report_{today}.md", "text/markdown")
        d[1].download_button("⬇️ Audit log (.txt)", txt, f"audit_{today}.txt", "text/plain")
        d[2].download_button("⬇️ CSV report", csv_text, f"report_{today}.csv", "text/csv")
        d[3].download_button("⬇️ JSON data", tracker.path.read_text(encoding="utf-8")
                             if tracker.path.suffix == ".json" else
                             to_df(tracker.items).to_json(orient="records", indent=2),
                             "pantry.json", "application/json")
        t1, t2, t3 = st.tabs(["Markdown preview", "Audit log", "CSV"])
        t1.markdown(md)
        t2.code(txt)
        t3.dataframe(pd.read_csv(io.StringIO(csv_text)), hide_index=True)
        if st.button("💾 Save all reports to the exports/ folder"):
            files = reports.export_all(tracker, EXPORT_DIR, today)
            st.success("Saved: " + ", ".join(p.name for p in files))
            png = [p for p in files if p.suffix == ".png"]
            if png:
                st.image(str(png[0]), caption="Status chart (Matplotlib)")

# ------------------------------------------------------------------ Bulk import
elif page == PAGES[5]:
    st.caption("Required columns: name, category, quantity, expiry_date. Optional: unit, location, "
               "purchase_date, notes. Common legacy headers (Item, Qty, Expiry Date, Storage) are recognised.")
    c1, c2 = st.columns(2)
    c1.download_button("⬇️ Download CSV template", sample_data.to_csv(sample_data.build_rows(today)[:3]),
                       "template.csv", "text/csv")
    use_demo = c2.checkbox("Use built-in legacy demo file (contains bad rows)")
    up = st.file_uploader("Upload a CSV", type=["csv"])
    skip_dup = st.checkbox("Skip duplicates (same name, expiry & location)", value=True)
    text = None
    if use_demo:
        text = sample_data.legacy_import_sample(today)
    elif up is not None:
        text = up.getvalue().decode("utf-8-sig", errors="replace")
    if text:
        try:
            st.caption("Preview")
            st.dataframe(pd.read_csv(io.StringIO(text), dtype=str).head(10), hide_index=True)
        except Exception:
            st.warning("Preview unavailable - the file will still be checked row by row.")
        if st.button("🚀 Import & validate", type="primary"):
            res = tracker.import_csv(text, today, skip_dup)
            if res.fatal:
                st.error(res.fatal)
            m = st.columns(4)
            m[0].metric("Rows read", res.total_rows)
            m[1].metric("Added", res.added)
            m[2].metric("Duplicates", res.duplicates)
            m[3].metric("Rejected", len(res.errors))
            if res.errors:
                st.subheader("Row-by-row error log")
                st.dataframe(pd.DataFrame(res.errors, columns=["Row", "Problem"]), hide_index=True)
            if res.warnings:
                with st.expander(f"{len(res.warnings)} warning(s)"):
                    st.dataframe(pd.DataFrame(res.warnings, columns=["Row", "Warning"]), hide_index=True)
            st.download_button("⬇️ Download error log", res.error_log(), "import_errors.log")

# ------------------------------------------------------------------ Settings
elif page == PAGES[6]:
    st.subheader("Warning threshold")
    warn = st.slider("Flag items as 'Expiring Soon' when they have this many days left",
                     3, 30, ss.warn_days)
    if warn != ss.warn_days:
        ss.warn_days = warn
        st.rerun()
    st.subheader("Storage")
    st.write(f"Data file: `{tracker.path.relative_to(ROOT)}` · {len(tracker.items)} items")
    fmt = st.radio("Format", ["JSON", "CSV"], horizontal=True,
                   index=0 if ss.data_file.endswith(".json") else 1)
    target = "pantry.json" if fmt == "JSON" else "pantry.csv"
    if target != ss.data_file and st.button(f"Convert & switch to {target}"):
        tracker.switch_file(DATA_DIR / target)
        ss.data_file = target
        st.rerun()
    st.subheader("Demo data")
    d1, d2 = st.columns(2)
    if d1.button("Add 40 sample items"):
        r = load_sample()
        st.success(f"Added {r.added} items ({r.duplicates} duplicates skipped).")
    if d2.button("Replace pantry with sample items"):
        r = load_sample(replace=True)
        st.success(f"Pantry replaced with {r.added} sample items.")
    st.subheader("Danger zone")
    if st.checkbox("I understand this deletes every item") and st.button("Delete all items"):
        tracker.clear()
        st.success("Pantry cleared.")
        st.rerun()
